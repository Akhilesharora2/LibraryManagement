﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RoleManagement.Models
{
    public class ConnectionClass: DbContext
    {
        public ConnectionClass(DbContextOptions<ConnectionClass> options) : base(options)
        {

        }
        public DbSet<StudentClass> BookIssue2 { get; set; }
    }
}
