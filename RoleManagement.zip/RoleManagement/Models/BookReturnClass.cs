﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RoleManagement.Models
{
    public class BookReturnClass : DbContext
    {
        public BookReturnClass(DbContextOptions<BookReturnClass> options) : base(options)
        {

        }
        public DbSet<ReturnClass> BookReturn { get; set; }
    }
}
