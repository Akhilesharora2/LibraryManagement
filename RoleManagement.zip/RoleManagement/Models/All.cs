﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RoleManagement.Models
{
    public class All:DbContext
    {
        public All(DbContextOptions<All> options) : base(options)
        {

        }
        public DbSet<Book> Book { get; set; }
    }
}
