﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RoleManagement.Models
{
    public class FindBookClass: DbContext
    {
        public FindBookClass(DbContextOptions<FindBookClass> options) : base(options)
        {

        }
        public DbSet<FindClass> Book{ get; set; }
    }
}
