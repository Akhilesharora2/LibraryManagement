﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RoleManagement.Models
{
    public class StudentClass
    {
        [Key]

        public int Id { get; set; }

        public string Email { get; set; }

        public string FullName { get; set; }

        public string StudentNo { get; set; }
        public string AuthorName { get; set; }
        public string BookName { get; set; }
        public string DateOfIssue { get; set; }
        public string DateOfReturn { get; set; }
    }
}
