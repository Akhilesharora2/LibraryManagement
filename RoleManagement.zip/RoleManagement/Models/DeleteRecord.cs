﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RoleManagement.Models
{
    public class DeleteRecord: DbContext
    {
        public DeleteRecord(DbContextOptions<DeleteRecord> options) : base(options)
        {

        }
        public DbSet<Delete> DeletedRecords { get; set; }
    }
}

