﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RoleManagement.Models;

namespace RoleManagement.Controllers
{
    [Authorize(Roles = "Admin")]
    public class StudentController : Controller
    {
        private readonly ConnectionClass _cc;
        private readonly BookReturnClass _dd;
        private readonly DeleteRecord _dr;
        public StudentController(ConnectionClass cc,BookReturnClass dd, DeleteRecord dr)
        {
            _dr = dr;
            _dd = dd;   
            _cc = cc;
        }
        public IActionResult Index()
        {
            var results = _cc.BookIssue2.ToList();
            var results2 = _dd.BookReturn.ToList();
            var results3 = _dr.DeletedRecords.ToList();
            foreach (var item in results){
                foreach (var item2 in results2)
                    if (item.StudentNo == item2.StudentNo)
                {
                        item.DateOfReturn = item2.DateOfReturn;
                }
                foreach (var item2 in results3)
                {
                    if(item.StudentNo == item2.StudentOrBook)
                    {
                        item.StudentNo = "XX";
                    }if(item.BookName == item2.StudentOrBook)
                    {
                        item.BookName = "XX";
                    }
                }
            }
            return View(results);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        
        public IActionResult Create(StudentClass bk)
        {
            _cc.Add(bk);
            _cc.SaveChanges();
            ViewBag.message = "The Record" + bk.FullName + "Saved Successfully.....!";
            return View();
        }

    }
}