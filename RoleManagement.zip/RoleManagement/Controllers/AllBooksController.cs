﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RoleManagement.Models;

namespace RoleManagement.Controllers
{
    public class AllBooksController : Controller
    {
        private readonly All _ab;
        private readonly FindBookClass _bb;
        public AllBooksController(All ab, FindBookClass bb)
        {
            _bb = bb;
            _ab = ab;
        }
        public IActionResult Index()
        {
            var results = _bb.Book.ToList();
            return View(results);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Book bk)
        {
            _ab.Add(bk);
            _ab.SaveChanges();
            ViewBag.message = "The Record" + bk.BookName + "Saved Successfully.....!";
            return View();
        }
    }
}