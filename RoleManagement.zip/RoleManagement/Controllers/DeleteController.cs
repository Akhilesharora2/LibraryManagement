﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RoleManagement.Models;

namespace RoleManagement.Controllers
{
    [Authorize(Roles = "Admin")]
    public class DeleteController : Controller
    {
        private readonly DeleteRecord _dr;

        public DeleteController(DeleteRecord dr)
        {
            _dr = dr;
        }
        public IActionResult Index()
        {
            var results = _dr.DeletedRecords.ToList();
            return View(results);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Delete bk)
        {
            _dr.Add(bk);
            _dr.SaveChanges();
            ViewBag.message = "The Record" + bk.StudentOrBook + "Deleted Successfully.....!";
            return View();
        }
    }
}